# Exercício 16
"""
Parabéns você está chegou a última questão do curso de Introdução ao Python!
Para comemorar escreva um código que imprime a mensagem "Parabéns! Você concluiu o curso de Introdução ao Python!" 100 vezes na tela!
"""
