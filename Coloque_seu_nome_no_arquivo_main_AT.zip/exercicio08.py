# Exercício 08
"""
Calcule o fatorial de um número informado pelo usuário.
O fatorial de um número n é o produto de todos os inteiros de 1 até n.

Exemplo de execução:
Digite um número: 5
O fatorial de 5 é 120
"""
