# Exercício 05
"""
Escreva um programa que dado o valor de N da variável abaixo calcula o valor da soma:
1 + 1/2 + 1/3 + 1/4 + ... + 1/N

Exemplo de execução:
Se N = 4,
o programa deverá calcular:
1 + 1/2 + 1/3 + 1/4 = 2.083333333333333

Saída esperada:
2.083333333333333
"""
n = 4
soma = 0

for i in range(n):
  soma += 1/(i+1)

print (round(soma,15))